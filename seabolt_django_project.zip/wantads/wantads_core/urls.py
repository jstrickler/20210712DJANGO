"""
URL Configuration for wantads_core
"""
from django.urls import path
from . import views   # import views from app

app_name = "wantads_core"

urlpatterns = [
    path('', views.home, name="home"),
    path('wantad_details/<str:pk>', views.WantadsDetail.as_view(), name="wantad_details"),
    path('wantad_form', views.WantadsCreate.as_view(), name="wantad_form"),
    path('wantad_search', views.wantad_search, name="wantad_search"),
    path('wantad_list', views.wantad_list, name="wantad_list"),
    # add url patterns for the wantads_core app here

    # Examples:
    # path('', views.home, name='home'),
    # path('thing', views.thing, name='thing'),
]
