from django.http import HttpResponse # only used in class (see comment below)
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from .models import Ad, Category
from django.views.generic import (
    ListView, CreateView, DetailView
)
from .forms import SearchForm

#from .forms import AdForm
# Create your views here.


def home(request):
    return render(request, 'wantads_core/home.html')

# never got the below to work; couldn't figure out how to pass the variable to a second view to load a new page or to display a list
# query specific to certain ads
def wantad_search(request):
    #all_ads = Ad.objects.all()

    if request.method == 'POST':  # bound form
        search_form = SearchForm(request.POST)
        var = search_form['search_char']
        #this_ad = "No Matches"
        # if Ad.objects.get(title=var):
        #     this_ad = Ad.objects.get(title=var)
        #
        context = {
             'success': var,
        #     'ad': this_ad
         }
        return render(request, 'wantads_core/home.html')  # ad_list.html

    else:
        search_form = SearchForm()  # unbound form
        context = {
            'search_form': search_form,
        }
        return render(request, 'wantads_core/home.html', context)

def wantad_list(request):
    all_ads = Ad.objects.all()
    context = {
        'ads': all_ads,
    }
    return render(request, 'wantads_core/ad_list.html', context)

class WantadsDetail(DetailView):
    model = Ad

class WantadsCreate(CreateView):
    model = Ad
    fields = ['title', 'price', 'date_added', 'email', 'phone', 'category']
    success_url = reverse_lazy('wantads_core:home')



# example without template (only used in class -- always use templates in real life):
# def home(request):
#     return HttpResponse("Welcome to wantads_core")

# example with template (normal Django approach)
# def home(request):
#     context = { 'message': "Welcome to wantads_core" }
#     return render(request, 'wantads_core/home.html', context)
