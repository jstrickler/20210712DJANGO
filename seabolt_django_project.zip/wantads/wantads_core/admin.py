from django.contrib import admin
# Register your models here.

# from .models import MyModel
from .models import Ad, Category
# admin.site.register(MyModel)

admin.site.register(Ad)
admin.site.register(Category)