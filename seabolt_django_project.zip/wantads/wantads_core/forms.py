from django import forms
from .models import Ad, Category
# Create your forms here.

#
# class AdForm(forms.ModelForm):
#     class Meta:
#         model = Ad
#         fields = ['title', 'price', 'date_added', 'email', 'phone', 'category']
#         labels = {
#             'title': 'Ad Title',
#             'price': 'Price',
#             'date_added': 'Date Added',
#             'email': 'Email',
#             'phone': 'Phone',
#             'category': 'Category',
#         }


class SearchForm(forms.Form):
    search_char = forms.CharField(max_length=256, label="")
