from django.db import models
import uuid


# Create your models here.
class Ad(models.Model):
    id = models.UUIDField(default=uuid.uuid4, primary_key=True, editable=False)
    title = models.CharField(max_length=64, unique=True)
    price = models.IntegerField(null=True)
    date_added = models.DateField(null=True)
    email = models.EmailField(null=True)
    phone = models.IntegerField(null=True)
    cat = models.CharField(max_length=64)

    def __str__(self):
        return self.title

    class Meta:
        db_table = "ad"


class Category(models.Model):
    id = models.UUIDField(default=uuid.uuid4, primary_key=True, editable=False)
    name = models.CharField(max_length=64)
    ad = models.ForeignKey(Ad, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

    class Meta:
        db_table = "category"
