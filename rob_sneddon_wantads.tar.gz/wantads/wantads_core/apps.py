from django.apps import AppConfig

class WantadsCoreConfig(AppConfig):
    name = "wantads_core"
