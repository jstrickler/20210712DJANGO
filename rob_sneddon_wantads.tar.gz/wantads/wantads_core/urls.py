"""
URL Configuration for wantads_core
"""
from django.urls import path
from . import views   # import views from app

app_name = "wantads_core"

urlpatterns = [
    # add url patterns for the wantads_core app here

    # Examples:
     path('', views.main_page, name='main_page'),
     path('ad_list', views.ad_list, name='ad_list'),
     path('ad_detail/<str:pk>', views.ad_detail, name='ad_detail'),
     path('ad_form', views.ad_form, name='ad_form'),
]
