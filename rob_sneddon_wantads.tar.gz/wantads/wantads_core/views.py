from django.http import HttpResponse  # only used in class (see comment below)
from django.shortcuts import render
from .models import Ad, Category
from .forms import adform

# Create your views here.


# example without template (only used in class -- always use templates in real life):
def main_page(request):
    return render(request, 'wantads_core/home.html')


def ad_list(request):
    all_ads = Ad.objects.all()
    context = {'ADS': all_ads}
    return render(request, 'wantads_core/ad_list.html', context)


def ad_detail(request, pk):
    items = Ad.objects.get(pk=pk)
    context = {'items': items}
    return render(request, 'wantads_core/ad_detail.html', context)

def ad_form(request):
    if request.method == 'POST':
        ad_form = adform(request.POST)
        if ad_form.is_valid():
            ad_form.save()
            return render(request, 'wantads_core/home.html')
    else:
        form = adform()
        context = {'ad_form': form}
        return render(request, 'wantads_core/ad_form.html', context)




# example with template (normal Django approach)
# def home(request):
#     context = { 'message': "Welcome to wantads_core" }
#     return render(request, 'wantads_core/home.html', context)
