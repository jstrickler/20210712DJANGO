from django import forms
from .models import Ad
# Create your forms here.
class adform(forms.ModelForm):
    class Meta:
        model = Ad
        fields = ['title', 'price', 'date_added','email','phone','cat']