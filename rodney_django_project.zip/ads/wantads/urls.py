"""
URL Configuration for wantads
"""
from django.urls import path
from . import views   # import views from app

app_name = "wantads"

urlpatterns = [
    # add url patterns for the wantads app here
    path('', views.home, name='home'),
    path('ads', views.ads_list, name='ads'),
    path('ads_form', views.ad_form, name='ads_form'),
    # Examples:
    # path('', views.home, name='home'),
    # path('thing', views.thing, name='thing'),
]
