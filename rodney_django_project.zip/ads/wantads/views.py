from django.http import HttpResponse  # only used in class (see comment below)
from django.shortcuts import render
from .models import Ad


# Create your views here.
def home(request):
    context = {'message': "Welcome to wantads_core"}
    return render(request, 'wantads/home.html', context)


def ads_list(request):
    all_ads = Ad.objects.all()
    context = {
        'ads': all_ads, }
    return render(request, 'wantads/ads.html', context)


def ad_form(request):
    # bound (filled-in) form
    if request.method == 'POST':
        form = Ad(request.POST)
        if form.is_valid():
            form.save()
            data = {
                "ad": form.cleaned_data
            }
            return render(request, 'wantads/ad_save.html', data)
    else:
        # unbound (empty) form
        form = Ad()
        data = {
            'form': form
        }
        return render(request, 'wantads/ads_form.html', data)

# example without template (only used in class -- always use templates in real life):
# def home(request):
#     return HttpResponse("Welcome to wantads_core")

# example with template (normal Django approach)
# def home(request):
#     context = { 'message': "Welcome to wantads_core" }
#     return render(request, 'wantads/home.html', context)
