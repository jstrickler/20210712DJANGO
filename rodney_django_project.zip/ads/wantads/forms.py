from django import forms

# Create your forms here.

from django import forms
from .models import Ad, Category


class DogForm(forms.ModelForm):
    class Meta:
        model = Ad
        fields = ['title', 'phone', 'email', 'category', 'date', 'price']
        labels = {
            'title': 'Ad title',
            'phone': 'Phone',
            'email': 'Email',
            'category': 'Category',
            'date': 'date',
            'price': 'price'
        }