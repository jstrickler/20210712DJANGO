import uuid
from django.db import models


class Category(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text="Unique ID of this category")
    name = models.CharField(max_length=64, unique=True, help_text="Name of category")

    class Meta:
        db_table = 'Category'

    def __str__(self):
        return f"{self.name}"


class Ad(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, help_text="Unique ID of this ad")
    title = models.CharField(max_length=64, help_text="Name of ad")
    price = models.IntegerField(help_text="Price in dollars")
    date_added = models.DateField(help_text="Date added")
    email = models.EmailField(max_length=254)
    phone = models.IntegerField(null=True, help_text="Phone number")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="categories", help_text="Ad category")

    class Meta:
        db_table = 'Ad'

    def __str__(self):
        return f"{self.title} {self.price}"
