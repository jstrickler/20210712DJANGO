from django.apps import AppConfig

class WantadsConfig(AppConfig):
    name = "wantads"
