from django.contrib import admin
from . models import Ad, Category
# Register your models here.
admin.site.register(Ad)
admin.site.register(Category)
# from .models import MyModel

# admin.site.register(MyModel)
