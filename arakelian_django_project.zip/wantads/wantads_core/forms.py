from django import forms

from .models import Ad
# Create your forms here.


class ByAdTitleForm(forms.Form):
    ad_title = forms.CharField(max_length=256, required=False)


class ByCategoryForm(forms.Form):
    category_name = forms.CharField(max_length=64, required=False)

