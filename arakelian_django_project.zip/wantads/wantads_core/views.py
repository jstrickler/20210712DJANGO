from django.http import HttpResponse # only used in class (see comment below)
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import DetailView, CreateView


# Create your views here.
from .models import Ad
from .forms import ByAdTitleForm, ByCategoryForm


def home(request):
    context = {
        'title_form': ByAdTitleForm(),
        'category_form': ByCategoryForm()
    }
    if request.method == 'POST':
        is_valid = False
        search_type = request.POST.get('search_type')
        if search_type == 'by_title':
            # Search ads by their title (icontains)
            form = ByAdTitleForm(request.POST)
            if form.is_valid():
                is_valid = True
                if form.cleaned_data['ad_title']:
                    context['search_results'] = Ad.objects.filter(title__icontains=form.cleaned_data['ad_title'])
                else:
                    context['search_results'] = Ad.objects.all()
                context['title_form'] = form
        else:
            # Search ads by their category name (icontains)
            form = ByCategoryForm(request.POST)
            if form.is_valid():
                is_valid = True
                if form.cleaned_data['category_name']:
                    context['search_results'] = Ad.objects.filter(category__name__icontains=form.cleaned_data['category_name'])
                else:
                    context['search_results'] = Ad.objects.all()
                context['category_form'] = form
        if is_valid:
            return render(request, 'wantads_core/wantads_core_main.html', context)
    else:
        return render(request, 'wantads_core/wantads_core_main.html', context)


class AdDetailView(DetailView):
    model = Ad


class AdCreateView(CreateView):
    model = Ad
    fields = ['title', 'price', 'date_added', 'email', 'phone_number', 'category']
    success_url = reverse_lazy('wantads_core:home')


# example without template (only used in class -- always use templates in real life):
# def home(request):
#     return HttpResponse("Welcome to wantads_core")

# example with template (normal Django approach)
# def home(request):
#     context = { 'message': "Welcome to wantads_core" }
#     return render(request, 'wantads_core/home.html', context)
