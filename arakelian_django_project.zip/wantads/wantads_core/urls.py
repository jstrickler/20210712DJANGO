"""
URL Configuration for wantads_core
"""
from django.urls import path
from . import views   # import views from app

app_name = "wantads_core"

urlpatterns = [
    # add url patterns for the wantads_core app here
    path('', views.home, name='home'),
    path('detail/<str:pk>', views.AdDetailView.as_view(), name='detail'),
    path('create_ad', views.AdCreateView.as_view(), name='create'),
    # Examples:
    # path('', views.home, name='home'),
    # path('thing', views.thing, name='thing'),
]
